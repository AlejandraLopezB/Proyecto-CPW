class SearchController < ApplicationController
  def index
    if (params[:opcion]=="1" || params[:opcion]=="2" || params[:opcion]=="3")
      @busqueda = params[:opcion]
    end
  	consulta = params[:q]
    @bloqueada = Bloqueada.new
  	if (@busqueda=="3")
  	  consulta = params[:q]+" pdf"
  	end
  	if (params[:q] && @busqueda == "1")
      page = params[:page] || 1
      @results = GoogleCustomSearchApi.search(params[:q],page: page)

    elsif (params[:q] && @busqueda == "2")
      page = params[:page] || 1
      options = {}
      options[:searchType] = "image"
      @results = GoogleCustomSearchApi.search(consulta, options)
    elsif (params[:q] && @busqueda == "3")
      page = params[:page] || 1
      @results = GoogleCustomSearchApi.search(consulta,page: page)
    end
  end
end
