class IdeaController < ApplicationController
  def new
    @random_words = ["electricidad","energia"] # Get 2 random words

    @random_images = [] # Prepare to store images


    options = {}
    
    options[:searchType] = "image" # Create an options hash to change search type to images


    @results = GoogleCustomSearchApi.search(@random_words[0], options)
 
  end

end
