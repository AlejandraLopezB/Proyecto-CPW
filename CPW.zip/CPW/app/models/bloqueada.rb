class Bloqueada < ActiveRecord::Base
end
