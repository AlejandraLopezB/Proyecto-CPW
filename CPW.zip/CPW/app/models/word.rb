class Word < ActiveRecord::Base
  def self.getRandomWords(count)
    words = []
    i = 0
    while i < count
      words.push getRandomWord
    end
  end

  def self.getRandomWord
    chosen_word = Word.offset( rand(Word.count) ).first.word
    return chosen_word
  end

end
